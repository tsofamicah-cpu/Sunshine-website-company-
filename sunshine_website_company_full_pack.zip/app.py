from flask import Flask, render_template, request, jsonify
from datetime import datetime
import csv
from pathlib import Path

app = Flask(__name__)

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
INQUIRIES = DATA_DIR / "inquiries.csv"

@app.route("/")
def home():
    return render_template("index.html")

@app.post("/api/contact")
def contact():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip()
    service = str(data.get("service", "")).strip()
    message = str(data.get("message", "")).strip()

    if not name or not email or not message:
        return jsonify(message="Please fill in your name, email and message."), 400

    new_file = not INQUIRIES.exists()
    with INQUIRIES.open("a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if new_file:
            writer.writerow(["date", "name", "email", "service", "message"])
        writer.writerow([datetime.now().isoformat(timespec="seconds"), name, email, service, message])

    return jsonify(message="Thank you! Your inquiry has been received."), 200

if __name__ == "__main__":
    app.run(debug=True)
