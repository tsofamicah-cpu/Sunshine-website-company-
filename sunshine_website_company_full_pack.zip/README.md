# Sunshine Website Company — Business Website

## Files
- `index.html` — main page
- `static/style.css` — responsive design
- `static/script.js` — menu and contact form
- `app.py` — Flask Python backend
- `requirements.txt` — dependency
- `data/` — inquiry storage (created automatically)

## Run locally
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run:
   `pip install -r requirements.txt`
4. Run:
   `python app.py`
5. Open `http://127.0.0.1:5000`

## Important
Replace the sample email and phone number in `templates/index.html` with your real business contact details before publishing.

The contact form stores inquiries in `data/inquiries.csv` when the Flask server is running.
