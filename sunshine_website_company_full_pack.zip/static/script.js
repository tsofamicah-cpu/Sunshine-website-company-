const menuBtn=document.getElementById("menuBtn");
const navLinks=document.getElementById("navLinks");
menuBtn.addEventListener("click",()=>navLinks.classList.toggle("open"));
document.querySelectorAll(".nav-links a").forEach(a=>a.addEventListener("click",()=>navLinks.classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();

const form=document.getElementById("contactForm");
const msg=document.getElementById("formMessage");
form.addEventListener("submit",async(e)=>{
  e.preventDefault();
  msg.textContent="Sending...";
  const data=Object.fromEntries(new FormData(form).entries());
  try{
    const res=await fetch("/api/contact",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    const result=await res.json();
    msg.textContent=result.message;
    if(res.ok) form.reset();
  }catch(err){
    msg.textContent="Could not connect to the server. Please try again.";
  }
});
